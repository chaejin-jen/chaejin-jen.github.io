const express = require('express')
const router = express.Router();

router.get('/' ,  (_, res) => {
    res.send('admin 이후 url');
});

router.get('/products' , (_, res) => {
    res.render('admin/products.html')
});

router.get('/products/write', (_, res) => {
    res.render('admin/write.html')
})

router.post('/products/write', (req, res) => {
    res.send(req.body)
})

module.exports = router;